      ================================
      ||    Homeworld: Cataclysm    ||
      || [AKA Homeworld: Emergence] ||
      ================================

http://homeworld.wikia.com/wiki/Homeworld:_Cataclysm

Models are copyright Sierra / Barking Dog Studios. 
Uploaded to the Models Resource / The VG Resource.

Ripped and converted by John2k4. No credit needed but if you use 'em 
for something cool, it'd be awesome if you message me :). 
Tool(s) used and conversion info at: http://2k4.co/gtools/index.html

Contact: 
E-Mail - rtd.john2k4 [at] gmail.com    -or-    Discord - John2k4#5788

LOD models are lower quality models that are loaded in based on how far away
the ship currently is from the camera. LOD0 is the highest quality model,
with LOD4 being the lowest quality model. 


