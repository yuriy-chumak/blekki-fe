Ripped & converted by John2k4, rtd.john2k4@gmail.com
Models are Copyright Relic Games


---------------
|What's a LOD?|
---------------

LOD is the degrading of the models quality as it gets farther from the camera. This allows for much improved performance in the game.

LOD0 is the highest quality, with quality diminishing as the number increases.




------------------
|What's a Goblin?|
------------------

Goblins are what the game refers to the "fine ship details" as. Small model details (such as antenna, fins, grills, etc) are stored in the "Goblins" folder.