Ripped by John2k4,  rtd.john2k4@gmail.com  for tMR only.
Models are copyright Sierra
No credit needed

--

LOD Specifies the model quality; 0 is highest, 4 is lowest.


====

Mining Base does not have a LOD4.