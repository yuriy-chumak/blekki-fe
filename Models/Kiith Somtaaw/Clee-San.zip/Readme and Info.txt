      ================================
      ||    Homeworld: Cataclysm    ||
      || [AKA Homeworld: Emergence] ||
      ================================

http://homeworld.wikia.com/wiki/Homeworld:_Cataclysm

Models are copyright Sierra / Relic / Barking Dog Studios. 
Uploaded to The Models Resource / The VG Resource.

Ripped and converted by John2k4. No credit needed but if you use 'em 
for something cool, it'd be awesome if you message me :). 
Tools used and conversion info at: http://2k4.co/gtools/index.html

Contact me: 
E-Mail - rtd.john2k4 [at] gmail.com    -or-    Discord - John2k4#5788

Some ships have accessory parts, like the command ship and carriers having 
support modules etc. I have tried to pack these in wherever possible, 
but if any are missing or can't be found, please contact me.

LOD models are lower quality models that are loaded in based on how far away
the ship currently is from the camera. This is done to save on graphics 
processing and to keep things running smoothly when many ships are on-screen.
LOD0 is the highest quality model of a ship, with LOD3/LOD4 being the lowest quality model. 
Some ships may only have LOD0/1/2/3. In addition, some may have parts or accessories
packed in with them. These include guns, buildable modules, etc.


