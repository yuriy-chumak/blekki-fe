Ripped by John2k4,  rtd.john2k4@gmail.com  for tMR only.
Models are copyright Sierra
No credit needed

--

LOD Specifies the model quality; 0 is highest, 4 is lowest.


====
NOTE
====
Raiders Mothership - the LOD0 model is broken, and therefore not included.